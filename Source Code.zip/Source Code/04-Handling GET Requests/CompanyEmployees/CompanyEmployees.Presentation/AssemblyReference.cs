﻿namespace CompanyEmployees.Presentation;

public static class AssemblyReference
{
}
