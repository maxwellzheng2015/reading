﻿namespace Service.Contracts;

public interface ICompanyService
{
}
