import numpy as np

print "Docstring", np.add.__doc__
print "Name", np.add.__name__
print "Nin", np.add.nin
print "Nout", np.add.nout
print "Nargs", np.add.nargs
print "Ntypes", np.add.ntypes
print "Types", np.add.types
