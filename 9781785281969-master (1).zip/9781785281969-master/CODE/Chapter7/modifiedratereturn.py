import numpy as np

print "Modified internal rate of return", np.mirr([-100, 38, 48, 90, 17, 36], 0.03, 0.03)
