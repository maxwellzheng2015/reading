import numpy as np

print "Interest rate", 12 * np.rate(167, -100, 9000, 0)
