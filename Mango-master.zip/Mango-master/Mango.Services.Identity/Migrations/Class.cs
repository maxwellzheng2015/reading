﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mango.Services.Identity.Migrations
{
    public class Class
    {

        static void Square(int a) {
            a = a * a;
            Console.WriteLine("Number: " + a);
        }
        static void Main(string[] args) {
            int num = 5;
            Console.WriteLine("Number: " + num);
            Square(num);
            Console.WriteLine("Number: " + num);
            Console.ReadLine();


            persons.where(p => p.Id == 1);

        }
    }



}
